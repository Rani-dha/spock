//package com.example.studenthostelallocation.entity;
//
//
//@Entity
//public class Hostel {
//    @Id
//    int hostelId;
//    int roomId;
//    int studentId;
//
//    public Hostel(int hostelId, int roomId, int studentId) {
//        this.hostelId = hostelId;
//        this.roomId = roomId;
//        this.studentId = studentId;
//    }
//
//    public Hostel() {
//    }
//
//    public int getHostelId() {
//        return hostelId;
//    }
//
//    public void setHostelId(int hostelId) {
//        this.hostelId = hostelId;
//    }
//
//    public int getRoomId() {
//        return roomId;
//    }
//
//    public void setRoomId(int roomId) {
//        this.roomId = roomId;
//    }
//
//    public int getStudentId() {
//        return studentId;
//    }
//
//    public void setStudentId(int studentId) {
//        this.studentId = studentId;
//    }
//}
