package com.example.studenthostelallocation.entity;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {

    @Id
    private int studentId;
    private String studentName;
    private String department;
    private int cellNumber;
    private int age;
    private double totalMonthlyExpenses;

    public Student(int studentId, String studentName, String department, int cellNumber, int age, double totalMonthlyExpenses) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.department = department;
        this.cellNumber = cellNumber;
        this.age = age;
        this.totalMonthlyExpenses = totalMonthlyExpenses;
    }

    public Student() {
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getCellNumber() {
        return cellNumber;
    }

    public void setCellNumber(int cellNumber) {
        this.cellNumber = cellNumber;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getTotalMonthlyExpenses() {
        return totalMonthlyExpenses;
    }

    public void setTotalMonthlyExpenses(double totalMonthlyExpenses) {
        this.totalMonthlyExpenses = totalMonthlyExpenses;
    }
}
