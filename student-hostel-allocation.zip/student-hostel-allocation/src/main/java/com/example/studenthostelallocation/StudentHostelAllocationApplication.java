package com.example.studenthostelallocation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentHostelAllocationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentHostelAllocationApplication.class, args);
	}

}
