package com.example.studenthostelallocation.service;
import com.example.studenthostelallocation.entity.*;
import com.example.studenthostelallocation.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class StudentHostelAllocationControllerService {

    @Autowired
    StudentRepository StudentRepository;
    public Student getStudentInfo(Integer studentId) {
        return StudentRepository.getAllBy(studentId);
    }
}
