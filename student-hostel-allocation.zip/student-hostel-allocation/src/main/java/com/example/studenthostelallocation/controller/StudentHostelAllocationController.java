package com.example.studenthostelallocation.controller;
import com.example.studenthostelallocation.entity.Student;
import com.example.studenthostelallocation.service.StudentHostelAllocationControllerService;

import groovyjarjarantlr4.v4.runtime.misc.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;


@RestController
@RequestMapping(value = "/student")
public class StudentHostelAllocationController {

    @Resource
    private StudentHostelAllocationControllerService studentHostelAllocationControllerService;

    @GetMapping("/info")
    public ResponseEntity<Student> getStudentInfo(@RequestParam @NotNull Integer studentId) {
        return ResponseEntity.ok(studentHostelAllocationControllerService.getStudentInfo(studentId));
    }

}
