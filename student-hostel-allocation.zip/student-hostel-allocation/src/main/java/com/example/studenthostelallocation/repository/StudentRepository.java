package com.example.studenthostelallocation.repository;

import com.example.studenthostelallocation.entity.Student;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
    Student getAllBy(int student);
}
