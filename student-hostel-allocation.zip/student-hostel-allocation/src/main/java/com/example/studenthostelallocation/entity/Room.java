package com.example.studenthostelallocation.entity;


//@Entity
public class Room {


}
